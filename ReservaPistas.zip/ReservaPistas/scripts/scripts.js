let deporteSeleccionado ={
    'deporte': 'desconocido',
    'numeroReservas':0
}
function nuevoCalendario(){
    let inputDeporte = document.getElementById('deporte').value;
    if(inputDeporte != ''){
        deporteSeleccionado.deporte = inputDeporte;
        const fechaActual = new Date();
        const posicionDiaActual = fechaActual.getDay();
        let posicionDia = 0;
        const numeroDias = obtenerCantidadDiasMes(fechaActual.getMonth(), fechaActual.getFullYear());
        let imprimirDia = 1;
        const dias = document.querySelectorAll('td');
        dias.forEach(element => {
            if(posicionDia != posicionDiaActual){
                posicionDia++;
            }else{
                if(imprimirDia <= numeroDias){
                    element.textContent = imprimirDia;
                    imprimirDia++;
                }
                
            }
            
        });
        let contarDias = contarDiasLibres();
        mensajeDiasLibres(contarDias);
    }else{
        alert('Inserte un deporte');
    }

}
function obtenerCantidadDiasMes(mes, year){
    return new Date(year, mes + 1, 0).getDate();
}
function mensajeDiasLibres(numeroDias){
    let i = 0;
    let divAvisos = document.getElementById('divAvisos');

    let idIntervalo =setInterval(() => {
        let parrafo = document.createElement('p');
        divAvisos.appendChild(parrafo);
        parrafo.textContent = 'Quedan '+(numeroDias - deporteSeleccionado.numeroReservas)+ ' días libres'
        i++;
        let comprobarSiQuedanDias = saberSiQuedanDias();
        if (i==15 || comprobarSiQuedanDias == true) {
                clearInterval(idIntervalo);
        }
    }, 3000);

}
function cambiarColor(casilla){
    if(deporteSeleccionado.deporte != 'desconocido' && casilla.textContent != ''){
        casilla.classList.add('casillaSeleccionada');
        deporteSeleccionado.numeroReservas++;
    }
}

function saberSiQuedanDias(){
    const dias = document.querySelectorAll('td');
    let diasDeDiario =[];
    let diasReservados = 0;
    dias.forEach(element => {
        if(element.classList != 'fondoViolet' && element.textContent != ''){
            diasDeDiario.push(element);
        }
    });
    diasDeDiario.forEach(element => {
        if(element.classList == 'casillaSeleccionada'){
            diasReservados++;
        }
    });
    if(diasReservados == diasDeDiario.length){
        alert('Ya no quedan días disponibles');
        setTimeout(() => {
            guardarDatos(); 
        }, 0);
        return true;
    }else{
        return false;
    }
}
function guardarDatos(){
    let URL = "http://localhost:3000/reservas";

    let init = {
    method: 'POST',
    body: JSON.stringify(deporteSeleccionado),
    headers: { 'Content-Type': 'application/json'}
    };
    fetch(URL, init)
    .then(response => response.json())
    .catch(err => console.error(err))
}

function contarDiasLibres(){
    const dias = document.querySelectorAll('td');
    let diasDeDiario =[];
    dias.forEach(element => {
        if(element.classList != 'fondoViolet' && element.textContent != ''){
            diasDeDiario.push(element);
        }
    });
    return diasDeDiario.length;
}
